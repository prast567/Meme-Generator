# Meme Generator

## Introduction
This is a Meme-Generator for Python, using PIL. It can generate meme with text along with author name .

## Requirements
The reuirements.txt mentions all the python dependencies needed to run this project.


## Installation

Make a virtual environment == > virtualenv venv

Activate the venv and run the requirements.txt ==> pip install -r requirements.txt

## Command-Line Usage

The program can be  executed from the command line also.

To run using CLI ==> python meme.py --path <path> --body <body> --author <author>

The program takes three OPTIONAL arguments:

--path ==> An image path
--body ==> A string quote body
--authorA ==> string quote author

The program returns a path to a generated image.
If any argument is not defined, a random selection is used.

## Web usage

The project completes the Flask app which can be started by running the app.py ==> python app.py	

app.py uses the Quote Engine module and Meme Generator modules to generate a random captioned image.

app.py uses the requests package to fetch an image from a user submitted URL.

