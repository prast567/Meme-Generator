""" create meme with image and quote """

from PIL import ImageFont
from PIL import Image
from PIL import ImageDraw
from random import randint
import os
from Exceptions import InvalidTextInput
from Exceptions import InvalidFilePath


class MemeEngine:
    """ cretae meme """

    def __init__(self, out_dir):
        self.out_dir = out_dir

    def make_meme(self, img_path, text, author, width= 500)-> str:
        """ Returns the path for generated meme
            Arguments:
                img_path {str} -- input image path
                text {str} -- body text
                author (str) -- author name
                width (int) -- width for the image(Max allowed is 500px)

        """
        if text == '':
            raise InvalidTextInput("Body is required to make a meme")
        else:
            if author == '':
                raise InvalidTextInput("Author Required if Body is Used")
            
        author = '- %s' % author
        try:
            img = Image.open(img_path)
        except Exception:
            raise InvalidFilePath("Invalid image path")
        image_size = img.size

        if image_size[0] > 500:
            ratio = width / float(img.size[0])
            height = int(ratio * float(img.size[1]))
            img = img.resize((width, height), Image.NEAREST)

        font = ImageFont.truetype("./Fonts/arial.ttf", 20)
        body_size = font.getsize(text)
        author_size = font.getsize(author)
        
        if body_size[0] > image_size[0] or author_size[0] > image_size[0]:
            raise InvalidTextInput("Too long input text")

        # select x and y cordinates in a way that the ebtire text fits into the image
        if body_size[0] > author_size[0]:
            bodyposition_x = randint(5, (image_size[0] - body_size[0]))
        else:
            bodyposition_x = randint(5, (image_size[0] - author_size[0]))

        bodyposition_y = randint(20, (image_size[1] - (body_size[1] + author_size[1] + 50)))
        bodyposition = (bodyposition_x, bodyposition_y)

        authorposition_x = bodyposition_x
        authorposition_y = bodyposition_y + 25
        authorposition = (authorposition_x, authorposition_y)

        draw = ImageDraw.Draw(img)

        # draw outlines
        outline = 1
        for x in range(-outline, outline + 1):
            for y in range(-outline, outline + 1):
                draw.text((bodyposition_x + x, bodyposition_y + y), text, (255, 255, 255), font=font)
                draw.text((authorposition_x + x, authorposition_y + y), author, (0, 0, 0), font=font)
        
        # draw quote
        draw.text(bodyposition, text, (0, 0, 0), font=font)
        draw.text(authorposition, author, (255, 255, 255), font=font)

        # get the input image_file name.
        imagefile = os.path.basename(img_path).split('.') 
        imagefile_name = imagefile[0]
        imagefile_ext = imagefile[1]
        
        # save the generated meme with name imagename_converted.ext
        out_path = os.path.join(self.out_dir, f'{imagefile_name}_meme{randint(0,100000000)}.{imagefile_ext}')
        img.save(out_path)

        return out_path
