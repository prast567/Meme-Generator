from typing import List

from .IngestorInterface import IngestorInterface
from .QuoteModel import QuoteModel
from .DocxIngestor import DocxIngestor
from .CSVIngestor import CSVIngestor
from .TextIngestor import TextIngestor
from .PDFIngestor import PDFIngestor
from Exceptions import InvalidFileFormat


class Ingestor(IngestorInterface):
    """ 
        Encapsulates all the ingestors to provide one 
        interface to load any supported file type.
    """
    ingestors = [TextIngestor, DocxIngestor, PDFIngestor, CSVIngestor]

    @classmethod
    def parse(cls, path: str) -> List[QuoteModel]:
        for ingestor in cls.ingestors:
            if ingestor.can_ingest(path):
                return ingestor.parse(path)
        else:
            raise InvalidFileFormat('Invalid file format')

            