from typing import List
import subprocess
import os
import random

from .IngestorInterface import IngestorInterface
from .QuoteModel import QuoteModel


class PDFIngestor(IngestorInterface):
    """ Process pdf files """

    allowed_extensions = ['pdf']

    @classmethod
    def parse(cls, path: str) -> List[QuoteModel]:
        """ Parse pdf and make quote object """
        
        tmp = f'./tmp/{random.randint(0,100000000)}.txt'
        subprocess.call(['./Lib/pdftotext.exe', path, tmp])
        
        quotes = []
        with open(tmp, "r") as file_ref:
            for line in file_ref.readlines():
                line = line.replace('"', '').replace(' - ', '-')
                temp = ''
                flag = 0
                for char in line:
                    temp += char
                    if char == '-':
                        body = temp.strip('-')
                        temp = ''
                        flag = 1
                    elif flag == 1 and char == ' ':
                        author = temp
                        temp = ''
                        flag = 0

                        new_quote = QuoteModel(body, author)
                        quotes.append(new_quote)

        os.remove(tmp)
        return quotes