from typing import List
from .IngestorInterface import IngestorInterface
from .QuoteModel import QuoteModel


class TextIngestor(IngestorInterface):
    """ Process text files """

    allowed_extensions = ['txt']

    @classmethod
    def parse(cls, path: str) -> List[QuoteModel]:
        """ Parse text and make quote object """
        
        quotes = []
        with open(path, "r") as file_ref:
            for line in file_ref.readlines():
                if len(line) > 0:
                    parse = line.strip().split('-')
                    new_quote = QuoteModel(parse[0], parse[1])
                    quotes.append(new_quote)
                    
        return quotes
