# Quote Engine
-- Module to make Quote

## IngesterInterface
-- An abstract base class, IngestorInterface, which defines:

-- A complete classmethod method is used to verify if the file type is compatible with the ingestor class.

-- An abstract method for parsing the file content (i.e., splitting each row) and outputting it to a Quote object.


## TextIngestor
-- The class inherits the IngestorInterface.
 
-- The parse method returns a valid QuoteModel


## PDFIngester
-- The class inherits from the IngestorInterface class.

-- The PDFIngestor class utilizes the subprocess module to call the pdftotext CLI utility—creating a pipeline that converts PDFs to text and then ingests the text.

-- The class handles deleting temporary files.

-- The parse method returns a valid QuoteModel

## DocxIngester
-- The class inherits from the IngestorInterface class.

-- The class depends on the python-docx library to complete the defined, abstract method signatures to parse DOCX files.

The parse method returns a valid QuoteModel

## CSVIngestor

-- The class inherits the IngestorInterface.

-- The class depends on the pandas library to complete the defined, abstract method signatures to parse CSV files.

-- The parse method returns a valid QuoteModel

## Ingestor
-- All ingestors are packaged into this main Ingestor class. This class encapsulates all the ingestors to provide one interface to load any supported file type.

