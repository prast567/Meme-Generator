# Exceptions

This module contains custom exceptions

InvalidFileFormat ==> Raise when file format is incorrect

InvalidTextInput ==> Raise when either body or author name is large than image size
    
InvalidFilePath ==> Raise when invalid image path is provided.
   
