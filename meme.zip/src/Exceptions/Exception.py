class InvalidFileFormat(Exception):
    pass


class InvalidTextInput(Exception):
    pass


class InvalidFilePath(Exception):
    pass
